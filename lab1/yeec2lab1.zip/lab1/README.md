Crystal Yee
Twitter Clicker

This is actually the first time I've used javascript so I used a lot of outside resources. Stack Overflow was a lifesaver, 
some of the W3 school tutorials were helpful, and I probably couldn't have completed the lab without the 20 or so
blogs I borrowed from. Getting the json to load from a true json file rather than a javascript file was difficult, but I 
also didn't know that the error console in the browser existed, so it was probably that. 

Bootstrap was more frustrating to use than helpful in my opinion. I spent over 2 hours trying and failing to change the default colors
to default structures. Changing the bosy color should not be difficult but it was. That being said the column system was really neat. 

I've never worked with CSS animations before either. Getting the animation to work was pretty simple, but for some reason it was 
really hard to get the animation to reset. If you happen to know why the line "element.offsetWidth = element.offsetWidth;" suddenly
makes the animation reset, I'd like to know why. 

